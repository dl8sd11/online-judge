#!/bin/bash

bash "${SANDBOX}/run.sh" "$@"
