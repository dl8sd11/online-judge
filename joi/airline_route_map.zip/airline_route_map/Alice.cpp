#include "Alicelib.h"
#include <cassert>
#include <cstdio>

void Alice( int N, int M, int A[], int B[] ){
	InitG( 3, 2 );
	MakeG( 1, 2 );
	MakeG( 1, 3 );
}

