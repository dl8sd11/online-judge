void Bob( int V, int U, int C[], int D[] );
void InitMap( int N, int M );
void MakeMap( int A, int B );
