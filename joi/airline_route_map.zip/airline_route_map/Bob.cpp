#include "Boblib.h"
#include <cassert>
#include <cstdio>

void Bob( int V, int U, int C[], int D[] ){
	InitMap( 3, 2 );
	MakeMap( 1, 2 );
	MakeMap( 1, 3 );
}

