void Solve(int N);

int Query(int u, int v, int w);
void Bridge(int u, int v);
