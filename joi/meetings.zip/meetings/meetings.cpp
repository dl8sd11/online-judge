#include "meetings.h"

void Solve(int N) {
  int x = Query(0, 1, 2);
  for (int u = 0; u < N - 1; ++u) {
    Bridge(u, u + 1);
  }
}
