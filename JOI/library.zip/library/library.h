#include <vector>
int Query(const std::vector<int>& M);
void Answer(const std::vector<int>& res);
