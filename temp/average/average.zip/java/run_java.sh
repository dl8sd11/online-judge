#!/bin/bash

problem=average

java -Xmx512M -Xss64M -jar "${problem}.jar" "grader"
