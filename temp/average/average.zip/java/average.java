public class average {
  public void init() {

  }

  public void addMonth(int K) {

  }

  public double maximumAverage(int L, int R) {
    return 0.0;
  }
}
