#include "average.h"

void init() {

}

void addMonth(int K) {

}

double maximumAverage(int L, int R) {
  return 0.0;
}
