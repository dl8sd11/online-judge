#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
#define REP(i,n) for(int i=0;i<n;i++)
#define ALL(a) a.begin(), a.end()
#define pb push_back

#define SZ(a) ((int)a.size())
const int maxn = 1000005;

int n;
vector<ll> pos,neg;
const ll MOD = 1000000007;
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int a, b, c;
    cin >> a >> b >> c;
    int xu = a+a+a+c-b-b, xd = a + c + a + c;
    int yu = b+b-c+a, yd = a + c +a+c;
    if(xu <= 0 || yu <= 0 || xu >= xd || yu >= yd)return cout << -1 << endl, 0;
    int g1 = __gcd(xu, xd), g2 = __gcd(yu, yd);
    cout << xu/g1 << "/" << xd/g1 << " " << yu/g2 << "/" << yd/g2 << endl;

}
