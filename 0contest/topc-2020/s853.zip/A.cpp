#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
#define REP(i,n) for(int i=0;i<n;i++)
#define ALL(a) a.begin(), a.end()
#define pb push_back

#define SZ(a) ((int)a.size())
const int maxn = 1000005;

int n;
vector<ll> pos,neg;
const ll MOD = 1000000007;
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);

    cin>>n;
    REP(i,n){
        ll x;
        cin>>x;
        if(x>=0) pos.pb(x);
        else neg.pb(x);
    }
    sort(ALL(pos));
    sort(ALL(neg));
    reverse(ALL(neg));

    if(SZ(pos)==0){
        for(auto i:neg){
            pos.pb(-i);
        }
        sort(ALL(pos));
        neg.clear();
    }
    if(SZ(neg)==0){
        ll mx=0, mn=0;
        REP(i,SZ(pos)){
            mx += pos[i] * pos.back();
            mn += pos[i] * pos[0];
        }
        mx -= pos.back()*pos.back();
        mn -= pos[0]*pos[0];
        mx%=MOD;
        mn%=MOD;
        cout<<mn<<' '<<mx<<'\n';
    }
    else{
        ll mn = 0, mx = 0;
        for(auto i:pos){
            mn += i*neg.back();
        }
        for(auto i:neg){
            mn += i*pos.back();
        }
        mn -= pos.back()*neg.back();
        mn%=MOD;
        mn=(mn+MOD)%MOD;

        mx += pos[0] * neg[0];
        for(auto i:pos){
            mx += i * pos.back();
        }
        mx -= pos.back()*pos.back();
        for(auto i:neg){
            mx += i * neg.back();
        }
        mx -= neg.back()*neg.back();

        mx%=MOD;
        mx += MOD;
        mx %=MOD;
        cout<<mn<<' '<<mx<<'\n';
    }

}
