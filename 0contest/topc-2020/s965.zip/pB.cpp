#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long lld;
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef pair<ld,ld> pdd;
#define ALL(a) a.begin(),a.end()
#define all(a) a.begin(),a.end()
#define SZ(i) int(i.size())
#define X first
#define Y second
#define REP(i,n) for(int i=0;i<n;i++)
#define eb emplace_back
#define pb push_back
#define MP(a,b) make_pair(a,b)
#define endl '\n'
int dis (pii a) {
    return a.Y - a.X;
}
    pii r1, r2;

    int x;

int fl (int p) {
    if (p >= x) return p-x;
    else return x-p;
}
pii tr (pii R) {
    int l = fl(R.X);
    int r = fl(R.Y);
    if (l >r) swap(l,r);
    return pii(l,r);
}

int mrg (pii l, pii r) {
    if (l.X > r.X) swap(l,r);
    if (l.Y <= r.X) return dis(l) +dis(r);
    else return dis(pii(min(l.X, r.X), max(l.Y, r.Y)));
}
int solve () {
    if (x<= r1.X || x>=r2.Y) {
        return dis(r1) + dis(r2);
    } else if (x >= r1.Y && x <= r2.X) {
        return mrg(tr(r1), tr(r2));
    } else if (x >= r1.X && x<=r1.Y) {
        return mrg(pii(0,max(r1.Y-x,x-r1.X)), tr(r2));
    } else {
        return mrg(pii(0,max(r2.Y-x, x-r2.X)), tr(r1));
    }
}
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);

    cin >> r1.X >> r1.Y >>r2.X >> r2.Y;

    int q;
    cin >> q;
    while (q--) {
        cin >>x;
        cout <<solve() <<endl;
    }
}
/*
1 3 8 9
10
1
2
3
4
5
6
7
8
9
10
*/
