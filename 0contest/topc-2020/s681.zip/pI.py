
a,b,c,d = [int(x) for x in input().split(' ')]
print(56*a +24*b +14*c + 6*d)