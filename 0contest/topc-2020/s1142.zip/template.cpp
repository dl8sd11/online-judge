#pragma GCC optimize("O3", "unroll-loops", "fast-math")
#pragma GCC target("avx","avx2","fma")
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;
typedef long long ll;
typedef long long lld;
typedef double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef pair<ld,ld> pdd;
#define ALL(a) a.begin(),a.end()
#define all(a) a.begin(),a.end()
#define SZ(i) int(i.size())
#define F first#define S second
#define ff first
#define ss second
#define REP(i,n) for(int i=0;i<n;i++)
#define eb emplace_back
#define pb push_back
#define MP(a,b) make_pair(a,b)

using namespace __gnu_pbds;

vector<pii> v;
//tree<pair<double,int>, null_type, less<pair<double, int>>, rb_tree_tag> st[2000];
priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> st[2000];
double dists[2000][2000];
vector<int> fix;
vector<double> ans;
double dist(int i, int j){
    return hypot(v[i].ff - v[j].ff, v[i].ss - v[j].ss);
}
//#define db
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int n = 2000;
    #ifndef db
    cin >> n;
    #endif
    //cout << n << endl;
    for(int i = 0; i < n; i++){
        int a, b;
    #ifdef db
        a = ll(rand()) * rand() % 1000000000;
        b = ll(rand()) * rand() % 1000000000;

    #else
        cin >> a >> b;
    #endif // db
        v.pb({a, b});
    }
    fix.resize(n);//ans.resize(n); //dists.resize(n); st.resize(n);

    //cout <<"f1" <<endl;
    //for(int i = 0; i < n; i++)dists[i].resize(n);
    for(int i = 0; i < n; i++)
        for(int j = i+1; j < n; j++)
            dists[i][j] = dists[j][i] = dist(i, j)/2,
            st[i].push({dists[i][j], j}),
            st[j].push({dists[i][j], i});
    //cout << "hi1" << endl;
    double aa = 0;
    for(int jj = 0; jj < n; jj++){
        pair<double, int> mns = {1e18, -1};
        for(int i = 0; i < n; i++)
            if(!fix[i]){
                while(dists[i][st[i].top().ss] != st[i].top().ff)st[i].pop();
                mns = min(mns, make_pair(st[i].top().ff, i));
            }
        fix[mns.ss] = true;
        aa += mns.ff*mns.ff;
        //st[mns.ss].clear();
        //cout << mns.ss << endl;
        for(int i = 0; i < n; i++)
            if(!fix[i])
                dists[mns.ss][i] = dists[i][mns.ss] = dist(i, mns.ss)-mns.ff,
                st[i].push({dists[mns.ss][i], mns.ss});
    }

    //cout <<"f2" <<endl;
    cout << setprecision(20) << fixed << aa*acosl(-1) << endl;
}
