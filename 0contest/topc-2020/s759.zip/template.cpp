#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long lld;
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef pair<ld,ld> pdd;
#define ALL(a) a.begin(),a.end()
#define all(a) a.begin(),a.end()
#define SZ(i) int(i.size())
#define F first#define S second
#define ff first
#define ss second
#define REP(i,n) for(int i=0;i<n;i++)
#define eb emplace_back
#define pb push_back
#define MP(a,b) make_pair(a,b)

vector<pii> v;

int main(){
    REP(i,10){
        if(i&1){
            for(int j=9;j>0;j--) v.eb(i,j);
        }
        else{
            for(int j=1;j<10;j++) v.eb(i,j);
        }
    }
    for(int i =9 ;i>=0;i--){
        v.eb(i,0);
    }


    int x,y;
    cin>>x>>y;

    bool f = 0;
    for(auto i:v){
        if(f || i == MP(x,y)){
            f=1;
            cout<<i.F<<' '<<i.S<<'\n';
        }
    }
    for(auto i:v){
        if(f){
            if(i==MP(x,y)) return 0;
            cout<<i.F<<' '<<i.S<<'\n';

        }
    }

}
