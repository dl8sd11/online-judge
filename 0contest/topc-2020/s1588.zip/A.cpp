#pragma GCC optimize("O3", "unroll-loops", "fast-math")
#pragma GCC target("avx","avx2","fma")
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;
typedef long long ll;
typedef long long lld;
typedef double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef pair<ld,ld> pdd;
#define ALL(a) a.begin(),a.end()
#define all(a) a.begin(),a.end()
#define SZ(i) int(i.size())
#define F first
#define S second
#define ff first
#define ss second
#define REP(i,n) for(int i=0;i<n;i++)
#define eb emplace_back
#define pb push_back
#define MP(a,b) make_pair(a,b)

using namespace __gnu_pbds;

vector<pii> v;
//tree<pair<double,int>, null_type, less<pair<double, int>>, rb_tree_tag> st[2000];
priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> st[2000];
double dists[2000][2000];
vector<int> fix;
vector<double> ans;
double dist(int i, int j){
    return hypot(v[i].ff - v[j].ff, v[i].ss - v[j].ss);
}

long double dp[30][30];
long double solve(){
    long double a, b;
    cin >> a >> b;

    for(int i = 0; i < 30; i++) for(int j = 0; j < 30; j++)dp[i][j] = 0;
    dp[0][0] = 1;

    long double ans = 0;

    long double duece = a*(1-b)/(1-a*b) + (1-a)*(1-b)*a/(1-(1-a)*(1-b));

    for (int i=0; i< 20; i++) {
        for (int j=0; j<=i; j++) {
            if ((i/2) % 2 == 0) { // A
                dp[i+1][j+1] += a * dp[i][j];
                dp[i+1][j] +=  (1-a)*dp[i][j];
            } else {
                dp[i+1][j+1] += (1-b) * dp[i][j];
                dp[i+1][j] +=  (b)*dp[i][j];
            }
        }
    }
    for(int i = 11; i <= 20; i++)ans += dp[20][i];
    ans += dp[20][10] * duece;
    return -20*pow(ans,7)+70*pow(ans, 6)-84*pow(ans, 5)+35*pow(ans, 4);
    // dp[i][j] := i rounds a wins j round
}


int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int t;
    cout << setprecision(20) << fixed;
    cin >> t;
    while(t--)cout << solve() << endl;
}
/*
5 4
2 3 + 1
1 2 + 4
2 4 * 3
3 4 + 2
*/
