#pragma GCC optimize("O3", "unroll-loops", "fast-math")
#pragma GCC target("avx","avx2","fma")
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;
typedef long long ll;
typedef long long lld;
typedef double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef pair<ld,ld> pdd;
#define ALL(a) a.begin(),a.end()
#define all(a) a.begin(),a.end()
#define SZ(i) int(i.size())
#define F first#define S second
#define ff first
#define ss second
#define REP(i,n) for(int i=0;i<n;i++)
#define eb emplace_back
#define pb push_back
#define MP(a,b) make_pair(a,b)

using namespace __gnu_pbds;

vector<pii> v;
//tree<pair<double,int>, null_type, less<pair<double, int>>, rb_tree_tag> st[2000];
priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> st[2000];
double dists[2000][2000];
vector<int> fix;
vector<double> ans;
double dist(int i, int j){
    return hypot(v[i].ff - v[j].ff, v[i].ss - v[j].ss);
}

const int mod = 1000000007;
int invmod(int a, int b = mod, int s0 = 0, int s1 = 1){
    return b? invmod(b, a%b, (s1 - (ll)a/b*s0%mod+mod)%mod, s0):s1;
}

//#define db
struct node{
    node *L, *R;
    int l, r, mid;
    int tag1 = -1, tag2 = -1, tag3 = 1; // ... val = ... val * tag3 + tag1 + tag2
    node(int ll, int rr) : l(ll), r(rr), mid((l+r)/2) {
        if(l != r)L = new node(l, mid), R = new node(mid+1, r);
    }
    void add_upd(int x){
        if(x == -1)return;
        if(tag1 == -1)tag1 = 0;
        tag1 += tag2;
        if(tag1 >= mod) tag1 -= mod;
        tag2 = x;
    }
    void mul_upd(int x){
        if(tag2 != -1) tag2 = (ll)tag2*x%mod;
        else tag3 = (ll)tag3*x%mod;
    }
    void down(){
        L->mul_upd(tag3);
        L->add_upd(tag1);
        L->add_upd(tag2);

        R->mul_upd(tag3);
        R->add_upd(tag1);
        R->add_upd(tag2);

        tag1 = tag2 = -1;
        tag3 = 1;
    }
    void add(int ll, int rr, int x){
        if(ll <= l && rr >= r)return add_upd(x);
        if(ll > r || rr < l)return;
        down();
        L->add(ll, rr, x);
        R->add(ll, rr, x);
    }
    void mul(int ll, int rr, int x){
        if(ll <= l && rr >= r)return mul_upd(x);
        if(ll > r || rr < l)return;
        down();
        L->mul(ll, rr, x);
        R->mul(ll, rr, x);
    }
    int ans(){
        if(l == r)return max(0, tag1) + max(0, tag2);
        down();
        return (L->ans() + R->ans())%mod;
    }
    void print(){
        if(l == r)cout << max(0, tag1) << "," << max(0, tag2) << " ";
        else down(), L->print(), R->print();
    }
} *root;

int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);

    int n, q;
    cin >> n >> q;
    root = new node(1, n);
    while(q--){
        int l, r, x; char c;
        cin >> l >> r >> c >> x;
        if(c == '+')
            root->add(l, r, x);
        else if(c == '-')
            root->add(l, r, x?mod-x:0);
        else if(c == '*')
            root->mul(l, r, x);
        else if(c == '/')
            root->mul(l, r, invmod(x));
        //root->print();cout << endl;
    }
    cout << root->ans() << endl;
}
/*
5 4
2 3 + 1
1 2 + 4
2 4 * 3
3 4 + 2
*/
