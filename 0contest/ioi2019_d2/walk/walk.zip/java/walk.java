class walk {
	public long min_distance(int[] x, int[] h, int[] l, int[] r, int[] y, int s, int g) {
		return 1;
	}
}
