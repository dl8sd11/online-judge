#include <vector>

std::vector<int> find_split(int n, int a, int b, int c, std::vector<int> p, std::vector<int> q);
