#include <vector>

long long count_rectangles(std::vector<std::vector<int> > a);
