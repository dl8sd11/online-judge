#include "rect.h"

long long count_rectangles(std::vector<std::vector<int> > a) {
	return 1;
}
