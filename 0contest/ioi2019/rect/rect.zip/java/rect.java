class rect {
	public long count_rectangles(int[][] a) {
		return 1;
	}
}
