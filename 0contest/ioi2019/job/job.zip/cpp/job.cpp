#include "job.h"
#include <vector>

long long scheduling_cost(std::vector<int> p, std::vector<int> u, std::vector<int> d) {
	return 0;
}
