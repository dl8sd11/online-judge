#include <vector>

long long scheduling_cost(std::vector<int> U, std::vector<int> D, std::vector<int> P);
