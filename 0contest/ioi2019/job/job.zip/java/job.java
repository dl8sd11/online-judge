class job {
	public int scheduling_cost(int[] p, int[] u, int[] d) {
		return 0;
	}
}
